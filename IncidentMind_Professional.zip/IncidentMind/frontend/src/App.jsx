import { useEffect, useMemo, useState } from 'react'
import './App.css'

const seedIncidents = [
  { id: 1, date: 'Oct 12, 2026', title: 'Payment API 503 Errors', rootCause: 'DB Pool Exhausted', resolution: 'Scaled DB + Optimized Queries', outcome: 'Resolved in 15 mins, no data loss.' },
  { id: 2, date: 'Aug 28, 2026', title: 'High Latency in Payments', rootCause: 'Traffic Spike', resolution: 'Added Auto Scaling', outcome: 'Latency returned to normal.' },
  { id: 3, date: 'Jul 15, 2026', title: 'Payment Failures', rootCause: 'Connection Pool Limit', resolution: 'Increased Pool Size', outcome: 'Payment processing restored.' },
]

const sampleText = 'Our payment service is down. Users are getting 503 errors while making payments.'

function parseAnalysis(text, problem) {
  const pick = (patterns, fallback) => {
    for (const pattern of patterns) {
      const match = text.match(pattern)
      if (match) return match[1].replace(/^\*+|\*+$/g, '').trim()
    }
    return fallback
  }
  return {
    rootCause: pick([/(?:likely\s*)?cause\s*[:\-]\s*([^\n]+)/i, /1\.\s*([^\n]+)/], 'Possible database connection pool exhaustion or a sudden traffic spike.'),
    action: pick([/(?:recommended\s*)?action\s*[:\-]\s*([^\n]+)/i, /2\.\s*([^\n]+)/], 'Check service health and database connection usage, then scale capacity if required.'),
    relevance: pick([/why[^:\n]*[:\-]\s*([^\n]+)/i, /3\.\s*([^\n]+)/], 'Similar incidents in memory point to resource saturation during high traffic.'),
    checks: pick([/(?:check|verify)[^:\n]*[:\-]\s*([^\n]+)/i, /4\.\s*([^\n]+)/], 'Monitor error rate, database pool utilization, and payment success rate.'),
    recommendation: 'Check database pool utilization and service health. Increase the pool only after confirming database capacity, then monitor payment success rate and 503 errors.'
  }
}

function App() {
  const [active, setActive] = useState('Dashboard')
  const [problem, setProblem] = useState(sampleText)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [incidents, setIncidents] = useState(seedIncidents)
  const [query, setQuery] = useState('')
  const [dark, setDark] = useState(false)
  const [notice, setNotice] = useState('')

  useEffect(() => {
    fetch('http://localhost:5000/incidents').then(r => r.json()).then(d => { if (d.success && Array.isArray(d.incidents) && d.incidents.length) setIncidents(d.incidents) }).catch(() => {})
  }, [])

  const filtered = useMemo(() => incidents.filter(item => `${item.title} ${item.rootCause} ${item.resolution}`.toLowerCase().includes(query.toLowerCase())), [incidents, query])

  async function analyzeIncident() {
    if (!problem.trim()) { setNotice('Please describe the incident first.'); return }
    setLoading(true); setNotice('')
    try {
      const response = await fetch('http://localhost:5000/incidents', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ problem }) })
      const data = await response.json()
      if (!response.ok || !data.success) throw new Error(data.error || 'Backend analysis failed')
      const analysis = data.analysis || parseAnalysis(data.recommendation || '', problem)
      setResult({ problem, ...analysis, recommendation: data.recommendation || analysis.recommendation, memories: data.memories || [], source: data.mode || 'AI + memory' })
      const newItem = { id: Date.now(), date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }), title: problem.length > 38 ? `${problem.slice(0, 38)}…` : problem, rootCause: analysis.rootCause, resolution: analysis.action, outcome: 'Analysis saved to incident history.' }
      setIncidents(prev => [newItem, ...prev.filter(x => x.id !== newItem.id)].slice(0, 12))
    } catch (error) {
      const fallback = parseAnalysis('', problem)
      setResult({ problem, ...fallback, source: 'Local demo mode', memories: [] })
      setNotice('Backend not connected. Showing a sample analysis so you can preview the dashboard. Start the backend to enable saved memory and AI analysis.')
    } finally { setLoading(false) }
  }

  function copySuggestion() {
    const text = result?.recommendation || 'Monitor the service and investigate the likely root cause.'
    navigator.clipboard?.writeText(text).then(() => setNotice('Recommendation copied to clipboard.')).catch(() => setNotice(text))
  }

  return (
    <div className={`app-shell ${dark ? 'dark' : ''}`}>
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark">✺</div><div><div className="brand-name">Incident<span>Mind</span></div><p>AI Production Incident<br/>Memory Agent</p></div></div>
        <nav>{[['▦','Dashboard'],['◷','Past Incidents'],['▥','Analytics'],['⚙','Settings']].map(([icon, label]) => <button key={label} className={`nav-item ${active === label ? 'selected' : ''}`} onClick={() => setActive(label)}><span>{icon}</span>{label}</button>)}</nav>
        <div className="sidebar-bottom"><div className="quote-icon">⚡</div><em>Learn from the past.<br/>Prevent the future.</em><div className="wave" /></div>
      </aside>
      <main className="main-area">
        <header className="topbar"><div className="mobile-brand">✺ Incident<span>Mind</span></div><div className="top-actions"><button className="icon-button" aria-label="Toggle theme" onClick={() => setDark(!dark)}>{dark ? '☾' : '☼'}</button><div className="avatar">N</div></div></header>
        <div className="page-content">
          {active === 'Dashboard' && <>
            <section className="welcome"><div><h1>Welcome back, Neha! <span>👋</span></h1><p>Turn past incidents into proactive solutions.</p></div><div className="status-pill"><i/> System ready</div></section>
            <section className="panel analyze-panel"><div className="panel-title"><span className="sparkle">✦</span><h2>Analyze an Incident</h2></div><textarea value={problem} onChange={e => setProblem(e.target.value)} placeholder="Describe the production incident..."/><div className="analyze-footer"><span>Describe the issue you're experiencing</span><button className="primary-button" onClick={analyzeIncident} disabled={loading}><span>✦</span>{loading ? 'Analyzing…' : 'Analyze'}</button></div></section>
            {notice && <div className="notice">ⓘ {notice}</div>}
            {result && <section className="panel result-panel"><div className="result-heading"><div className="check-circle">✓</div><div><h2>Incident Analysis Complete!</h2><p>Here’s what we found · <span className="mode-label">{result.source}</span></p></div></div><div className="result-grid"><div className="insights"><h3>💡 &nbsp;Key Insights</h3><dl><dt>Root Cause:</dt><dd>{result.rootCause}</dd><dt>What to Do:</dt><dd>{result.action}</dd><dt>Why Relevant:</dt><dd>{result.relevance}</dd><dt>What to Check:</dt><dd>{result.checks}</dd></dl></div><div className="recommendation"><h3>★ &nbsp;Recommendation</h3><p>{result.recommendation}</p><button className="copy-button" onClick={copySuggestion}>▣ &nbsp; Copy Suggestion</button></div></div></section>}
            <IncidentTable incidents={incidents.slice(0, 3)} onView={() => setActive('Past Incidents')} />
          </>}
          {active === 'Past Incidents' && <><div className="page-heading"><h1>Past Incidents</h1><p>Review what happened and how your team resolved it.</p></div><IncidentTable incidents={filtered} searchable query={query} setQuery={setQuery} /></>}
          {active === 'Analytics' && <><div className="page-heading"><h1>Analytics</h1><p>A quick overview of your incident memory.</p></div><div className="stats-grid"><Stat label="Total Incidents" value={incidents.length} icon="▤"/><Stat label="Resolved Incidents" value={incidents.length} icon="✓"/><Stat label="Memory Entries" value={incidents.length} icon="◉"/></div><section className="panel analytics-panel"><h2>Recent Incident Activity</h2>{incidents.slice(0,5).map((item,i)=><div className="activity-row" key={item.id}><span className="activity-dot"/><div><b>{item.title}</b><small>{item.date} · {item.rootCause}</small></div><span className="resolved">Resolved</span></div>)}</section></>}
          {active === 'Settings' && <><div className="page-heading"><h1>Settings</h1><p>Manage your IncidentMind workspace.</p></div><section className="panel settings-panel"><h2>Workspace preferences</h2><div className="setting-row"><div><b>Appearance</b><small>Switch between light and dark dashboard themes.</small></div><button className="copy-button" onClick={() => setDark(!dark)}>{dark ? 'Dark mode' : 'Light mode'} · Change</button></div><div className="setting-row"><div><b>AI & Memory connection</b><small>Groq and Hindsight are configured through the backend .env file.</small></div><span className="status-pill"><i/> Local backend</span></div><div className="setting-row"><div><b>Demo data</b><small>Sample incidents are included to help you preview the dashboard.</small></div><span className="muted">{incidents.length} entries</span></div></section></>}
          <footer className="footer">IncidentMind <span>·</span> Learn from the past. Prevent the future.</footer>
        </div>
      </main>
    </div>
  )
}

function Stat({ label, value, icon }) { return <div className="stat-card"><div className="stat-icon">{icon}</div><div><small>{label}</small><strong>{value}</strong></div></div> }
function IncidentTable({ incidents, onView = () => {}, searchable = false, query = '', setQuery = () => {} }) {
  return <section className="panel table-panel"><div className="table-heading"><div className="panel-title"><span className="database-icon">▤</span><h2>{searchable ? 'All Past Incidents' : 'Similar Past Incidents'}</h2></div><div className="table-tools">{searchable && <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search incidents…"/>}<button className="view-all" onClick={onView}>{searchable ? 'Refresh view' : 'View All'} →</button></div></div><div className="table-scroll"><table><thead><tr><th>Date</th><th>Incident</th><th>Root Cause</th><th>Resolution</th></tr></thead><tbody>{incidents.length ? incidents.map(item => <tr key={item.id}><td>{item.date}</td><td>{item.title}</td><td>{item.rootCause}</td><td>{item.resolution}</td></tr>) : <tr><td colSpan="4" className="empty">No matching incidents found.</td></tr>}</tbody></table></div></section>
}

export default App
